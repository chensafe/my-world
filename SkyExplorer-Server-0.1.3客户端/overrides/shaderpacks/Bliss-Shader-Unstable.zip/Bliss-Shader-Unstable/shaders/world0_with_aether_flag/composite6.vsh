#version 120

#define OVERWORLD_SHADER
#define AETHER_FLAG

#include "/dimensions/composite6.vsh"