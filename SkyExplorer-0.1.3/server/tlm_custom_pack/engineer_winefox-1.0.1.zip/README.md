# Winefox YSM Models

A collection of custom **Yes Steve Model / YSM** character models for Minecraft.

## Engineer Winefox

**Engineer Winefox** is a Minecraft YSM model inspired by **Create mod machinery**, red-robed engineers, servo arms, and a light **Adeptus Mechanicus / Tech-priest / Omnissiah** aesthetic.

She is a small fox-eared engineer obsessed with brass gears, kinetic contraptions, cake, and the mysterious “machine spirit” inside every device.

Originally, she was only responsible for testing workshop machines.
But after mixing Create-style kinetic components, andesite casings, brass gears, and a strange machine-spirit ritual, she became the Engineer Winefox.

Now she travels with a mechanical backpack, servo arm, wrench, goggles, and enough cake to survive any mining expedition.

> “I think, therefore the machine spirit listens.”

## Tags

`Minecraft` `YSM` `Yes Steve Model` `Winefox` `Engineer Winefox` `Create mod inspired` `kinetic machinery` `brass gears` `andesite casing` `servo arm` `Tech-priest inspired` `Adeptus Mechanicus inspired` `Omnissiah inspired` `Warhammer 40k inspired` `fox girl engineer`

# 工程师酒狐

**工程师酒狐·黄铜工坊修会** 是一个适用于 **Yes Steve Model / YSM** 的 Minecraft 角色模型。

她是一位沉迷齿轮、黄铜与蛋糕的狐耳工程师。  
原本只是工坊里负责调试机械的小小酒狐，直到某次实验中，她把机械动力组件、安山机壳、黄铜齿轮和一件“不知从哪里捡来的红色圣物”接在了一起。

自那以后，她开始坚信每台机器里都住着需要被安抚的“机魂”。  
于是，她披上深红短袍，戴上工程师护目镜，背起动力背包与机械臂，随身携带扳手、熏香炉和一小块备用蛋糕，在工坊与矿洞之间认真执行自己的“机魂净化仪式”。

没人知道那件红色圣物到底来自哪里。  
酒狐本人只表示：

> “我寻思这样接，机器就会更听话。”

---

## 模型特色

- 深红色工程师短袍
- 狐耳酒狐角色外观
- 工程师护目镜
- 动力背包与机械臂
- 黄铜、齿轮、工坊风格设计
- 机魂净化仪式主题演出
- 面具、斗篷、螺旋桨、表情包等可切换元素

---

## 适用环境

本模型适用于 Minecraft 的 **Yes Steve Model / YSM** 模型系统。

请确认你已经正确安装 YSM，并按照 YSM 的模型导入方式放置本模型文件。

---

## 动作与切换项

模型包含以下扩展项目：

- 面具穿戴
- 斗篷穿戴
- 螺旋桨大小调整
- 熏香净化仪式
- 表情包挂件

不同版本的 YSM 或动画控制器可能会影响部分动作与开关的显示效果。

---

## 文件说明
**模型文件本体不能卖，不能付费分发；但拿它拍视频、直播、做展示内容可以。**
常见目录结构如下：

```text
工程师酒狐/
├─ avatar/
├─ animations/
├─ controller/
├─ models/
├─ textures/
└─ ysm.json
